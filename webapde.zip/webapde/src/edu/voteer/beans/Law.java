package edu.voteer.beans;

import java.io.Serializable;
import java.sql.Date;

public class Law implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String LAW_TABLE_NAME = "laws";
	public static final String LAW_LAW_ID = "law_id";
	public static final String LAW_CANDIDATE_ID = "candidate_id";
	public static final String LAW_TITLE = "title";
	public static final String LAW_AKA = "aka";
	public static final String LAW_DATE = "date";
	public static final String LAW_DESCRIPTION = "description";
	public static final String LAW_URL = "url";

	private int law_id;
	private int candidate_id;
	private String title;
	private String aka;
	private Date date;
	private String description;
	private String url;
	
	public Law(){
		
	}

	public Law(int law_id, int candidate_id, String title, String aka, Date date, String description, String url) {
		super();
		this.law_id = law_id;
		this.candidate_id = candidate_id;
		this.title = title;
		this.aka = aka;
		this.date = date;
		this.description = description;
		this.url = url;
	}
	
	public Law(int candidate_id, String title, String aka, Date date, String description, String url) {
		super();
		this.candidate_id = candidate_id;
		this.title = title;
		this.aka = aka;
		this.date = date;
		this.description = description;
		this.url = url;
	}

	public int getLaw_id() {
		return law_id;
	}

	public void setLaw_id(int law_id) {
		this.law_id = law_id;
	}

	public int getCandidate_id() {
		return candidate_id;
	}

	public void setCandidate_id(int candidate_id) {
		this.candidate_id = candidate_id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAka() {
		return aka;
	}

	public void setAka(String aka) {
		this.aka = aka;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}
