package edu.voteer.beans;

import java.io.Serializable;

public class Academic implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String ACADEMIC_TABLE_NAME = "academics";
	public static final String ACADEMIC_ACADEMIC_ID = "academic_id";
	public static final String ACADEMIC_CANDIDATE_ID = "candidate_id";
	public static final String ACADEMIC_DEGREE  = "degree";
	public static final String ACADEMIC_INSTITUTION = "institution";
	

	private int academic_id;
	private int candidate_id;
	private String degree;
	private String institution;
	
	public Academic(){
		
	}
	
	
	
	public Academic(int academic_id, int candidate_id, String degree, String institution) {
		super();
		this.academic_id = academic_id;
		this.candidate_id = candidate_id;
		this.degree = degree;
		this.institution = institution;
	}
	
	public Academic(int candidate_id, String degree, String institution) {
		super();
		this.candidate_id = candidate_id;
		this.degree = degree;
		this.institution = institution;
	}



	public String getInstitution() {
		return institution;
	}



	public void setInstitution(String institution) {
		this.institution = institution;
	}



	public int getAcademic_id() {
		return academic_id;
	}
	public void setAcademic_id(int academic_id) {
		this.academic_id = academic_id;
	}
	public int getCandidate_id() {
		return candidate_id;
	}
	public void setCandidate_id(int candidate_id) {
		this.candidate_id = candidate_id;
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	
	

}

