package edu.voteer.beans;

import java.io.Serializable;
import java.sql.Date;

public class Candidate implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String CANDIDATE_TABLE_NAME = "candidates";
	public static final String CANDIDATE_CANDIDATE_ID = "candidate_id";
	public static final String CANDIDATE_FIRSTNAME = "firstname";
	public static final String CANDIDATE_NICKNAME = "nickname";
	public static final String CANDIDATE_MIDDLENAME = "middlename";
	public static final String CANDIDATE_LASTNAME = "lastname";
	public static final String CANDIDATE_BIRTHDATE = "birthdate";
	public static final String CANDIDATE_FATHER = "father";
	public static final String CANDIDATE_MOTHER = "mother";
	public static final String CANDIDATE_RELIGION = "religion";
	public static final String CANDIDATE_PICTURE = "picture";
	public static final String CANDIDATE_POSITION = "position";
	public static final String CANDIDATE_DESCRIPTION = "description";

	private int candidate_id;
	private String firstname;
	private String nickname;
	private String middlename;
	private String lastname;
	private Date birthdate;
	private String father;
	private String mother;
	private String religion;
	private String picture;
	private String position;
	private String description;

	public Candidate(){
		
	}
	

	public Candidate(int candidate_id, String firstname, String nickname, String middlename, String lastname,
			Date birthdate, String father, String mother, String religion, String picture, String position,
			String description) {
		super();
		this.candidate_id = candidate_id;
		this.firstname = firstname;
		this.nickname = nickname;
		this.middlename = middlename;
		this.lastname = lastname;
		this.birthdate = birthdate;
		this.father = father;
		this.mother = mother;
		this.religion = religion;
		this.picture = picture;
		this.position = position;
		this.description = description;
	}

	public int getCandidate_id() {
		return candidate_id;
	}

	public void setCandidate_id(int candidate_id) {
		this.candidate_id = candidate_id;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getMiddlename() {
		return middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public Date getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(Date birthdate) {
		this.birthdate = birthdate;
	}

	public String getFather() {
		return father;
	}

	public void setFather(String father) {
		this.father = father;
	}

	public String getMother() {
		return mother;
	}

	public void setMother(String mother) {
		this.mother = mother;
	}

	public String getReligion() {
		return religion;
	}

	public void setReligion(String religion) {
		this.religion = religion;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}


}
