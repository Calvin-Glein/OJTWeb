package edu.voteer.beans;

import java.io.Serializable;
import java.sql.Date;

public class Bill implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String BILL_TABLE_NAME = "bills";
	public static final String BILL_BILL_ID = "bill_id";
	public static final String BILL_CANDIDATE_ID = "candidate_id";
	public static final String BILL_TITLE = "title";
	public static final String BILL_AKA = "aka";
	public static final String BILL_DESCRIPTION = "description";
	public static final String BILL_DATE = "date";
	public static final String BILL_URL = "url";

	private int bill_id;
	private int candidate_id;
	private String title;
	private String aka;
	private String description;
	private Date date;
	private String url;

	public Bill() {

	}

	public Bill(int bill_id, int candidate_id, String title, String aka, String description, Date date, String url) {
		super();
		this.bill_id = bill_id;
		this.candidate_id = candidate_id;
		this.title = title;
		this.aka = aka;
		this.description = description;
		this.date = date;
		this.url = url;
	}

	public Bill(int candidate_id, String title, String aka, String description, Date date, String url) {
		this.candidate_id = candidate_id;
		this.title = title;
		this.aka = aka;
		this.description = description;
		this.date = date;
		this.url = url;
	}

	public int getBill_id() {
		return bill_id;
	}

	public void setBill_id(int bill_id) {
		this.bill_id = bill_id;
	}

	public int getCandidate_id() {
		return candidate_id;
	}

	public void setCandidate_id(int candidate_id) {
		this.candidate_id = candidate_id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAka() {
		return aka;
	}

	public void setAka(String aka) {
		this.aka = aka;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}
