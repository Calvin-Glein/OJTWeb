package edu.voteer.beans;

import java.io.Serializable;

public class GovernmentProject implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String GOVERNMENTPROJECT_GOVERNMENTPROJECT_TABLE_NAME = "government_projects";
	public static final String GOVERNMENTPROJECT_GOVERNMENT_PROJECT_ID = "government_project_id";
	public static final String GOVERNMENTPROJECT_CANDIDATE_ID = "candidate_id";
	public static final String GOVERNMENTPROJECT_TITLE = "title";
	public static final String GOVERNMENTPROJECT_DESCRIPTION = "description";

	private int government_project_id;
	private int candidate_int;
	private String title;
	private String description;

	public GovernmentProject() {

	}

	public GovernmentProject(int government_project_id, int candidate_int, String title, String description) {
		super();
		this.government_project_id = government_project_id;
		this.candidate_int = candidate_int;
		this.title = title;
		this.description = description;
	}

	public GovernmentProject(int candidate_int, String title, String description) {
		super();
		this.candidate_int = candidate_int;
		this.title = title;
		this.description = description;
	}

	public int getGovernment_project_id() {
		return government_project_id;
	}

	public void setGovernment_project_id(int government_project_id) {
		this.government_project_id = government_project_id;
	}

	public int getCandidate_int() {
		return candidate_int;
	}

	public void setCandidate_int(int candidate_int) {
		this.candidate_int = candidate_int;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
