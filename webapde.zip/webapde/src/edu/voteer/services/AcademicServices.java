package edu.voteer.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import edu.voteer.beans.Academic;
import edu.voteer.beans.AcademicAward;
import edu.voteer.beans.AcademicComposite;
import edu.voteer.db.DBPool;

public class AcademicServices {
	public static void addAcademic(Academic a) {
		String sql = "INSERT INTO " + Academic.ACADEMIC_TABLE_NAME + " (" + Academic.ACADEMIC_CANDIDATE_ID + ", "
				+ Academic.ACADEMIC_DEGREE + ", " + Academic.ACADEMIC_INSTITUTION + ") VALUES (?, ?,?)";

		Connection conn = DBPool.getInstance().getConnection();

		// use preparedstatement to prevent sql injection

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, a.getCandidate_id());
			pstmt.setString(2, a.getDegree());
			pstmt.setString(3, a.getInstitution());

			pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public static ArrayList<Academic> getAllAcademic() {
		ArrayList<Academic> academics = new ArrayList<>();

		String sql = "Select * from " + Academic.ACADEMIC_TABLE_NAME + ";";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				Academic a = new Academic();
				a.setAcademic_id(rs.getInt(Academic.ACADEMIC_ACADEMIC_ID));
				a.setCandidate_id(rs.getInt(Academic.ACADEMIC_CANDIDATE_ID));
				a.setDegree(rs.getString(Academic.ACADEMIC_DEGREE));
				a.setInstitution(rs.getString(Academic.ACADEMIC_INSTITUTION));

				academics.add(a);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return academics;
	}

	public static void updateAcademic(Academic a) {
		String sql = "UPDATE " + Academic.ACADEMIC_TABLE_NAME + " SET " + Academic.ACADEMIC_CANDIDATE_ID + " = ?, "
				+ Academic.ACADEMIC_DEGREE + " = ? " + " WHERE " + AcademicAward.ACADEMICAWARD_ACADEMIC_AWARD_ID
				+ " = ?;";

		Connection conn = DBPool.getInstance().getConnection();
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, a.getCandidate_id());
			pstmt.setString(2, a.getDegree());

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public static void deleteAcademic(int academic_id) {

		String sql = "DELETE FROM " + Academic.ACADEMIC_TABLE_NAME + " WHERE " + Academic.ACADEMIC_ACADEMIC_ID + " =?";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, academic_id);

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

	}

	public static ArrayList<AcademicComposite> getAllAcademicComposite(int candidate_id) {
		ArrayList<AcademicComposite> academicComposites = new ArrayList<>();
		String sql = "SELECT * from " + Academic.ACADEMIC_TABLE_NAME + " , " + AcademicAward.ACADEMICAWARD_TABLE_NAME
				+ " where academics.academic_id = academic_awards.academic_id and academics.candidate_id = ?;";
		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, candidate_id);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				AcademicComposite a = new AcademicComposite();
				a.setAcademic_id(rs.getInt(Academic.ACADEMIC_ACADEMIC_ID));
				a.setCandidate_id(rs.getInt(Academic.ACADEMIC_CANDIDATE_ID));
				a.setDegree(rs.getString(Academic.ACADEMIC_DEGREE));
				a.setInstitution(rs.getString(Academic.ACADEMIC_INSTITUTION));
				a.setAward_title(rs.getString(AcademicAward.ACADEMICAWARD_AWARD_TITLE));

				academicComposites.add(a);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return academicComposites;
	}

}
