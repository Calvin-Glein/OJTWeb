package edu.voteer.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import edu.voteer.beans.User;
import edu.voteer.db.DBPool;

public class UserServices {
	public static void addUser(User u) {
		String sql = "INSERT INTO " + User.USER_TABLE_NAME + " (" + User.USER_USERNAME + ", " + User.USER_PASSWORD
				+ ") VALUES (?, ?)";

		Connection conn = DBPool.getInstance().getConnection();
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, u.getUsername());
			pstmt.setString(2, u.getPassword());

			pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public static ArrayList<User> getAllUser() {
		ArrayList<User> users = new ArrayList<>();

		String sql = "Select * from " + User.USER_TABLE_NAME + ";";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				User u = new User();
				u.setUser_id(rs.getInt(User.USER_USER_ID));
				u.setUsername(rs.getString(User.USER_USERNAME));
				u.setPassword(rs.getString(User.USER_PASSWORD));

				users.add(u);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return users;
	}

	public static User getUserAccount(String username, String password) {
		User u = new User();
		u.setUser_id(-1);
		String sql = "Select * from " + User.USER_TABLE_NAME + " where " + User.USER_USERNAME
				+ " = ? and " + User.USER_PASSWORD + " = ?";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		
		ResultSet rs = null;
		try {
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, username);
			pstmt.setString(2, password);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				u = new User();
				u.setUser_id(rs.getInt(User.USER_USER_ID));
				u.setUsername(rs.getString("username"));
				u.setPassword(rs.getString(User.USER_PASSWORD));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		System.out.println("QWERTYUIO: " + u.getUser_id());
		return u;
		

	}
}
