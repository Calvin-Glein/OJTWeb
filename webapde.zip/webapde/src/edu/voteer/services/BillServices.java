package edu.voteer.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import edu.voteer.beans.AcademicAward;
import edu.voteer.beans.Bill;
import edu.voteer.db.DBPool;

public class BillServices {
	public static void addBill(Bill b) {
		String sql = "INSERT INTO " + Bill.BILL_TABLE_NAME + " (" + Bill.BILL_CANDIDATE_ID + ", " + Bill.BILL_TITLE
				+ "," + Bill.BILL_AKA + "," + Bill.BILL_DESCRIPTION + "," + Bill.BILL_DATE + "," + Bill.BILL_URL
				+ ") VALUES (?, ?, ?, ?, ?, ?)";

		Connection conn = DBPool.getInstance().getConnection();

		// use preparedstatement to prevent sql injection

		PreparedStatement pstmt = null;

		System.out.println(sql);

		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, b.getCandidate_id());
			pstmt.setString(2, b.getTitle());
			pstmt.setString(3, b.getAka());
			pstmt.setString(4, b.getDescription());
			pstmt.setDate(5, b.getDate());
			pstmt.setString(6, b.getUrl());

			pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public static ArrayList<Bill> getAllBill() {
		ArrayList<Bill> bills = new ArrayList<>();
		String sql = "Select * from " + Bill.BILL_TABLE_NAME + ";";

		Connection conn = DBPool.getInstance().getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				Bill b = new Bill();
				b.setBill_id(rs.getInt(Bill.BILL_BILL_ID));
				b.setCandidate_id(rs.getInt(Bill.BILL_CANDIDATE_ID));
				b.setTitle(rs.getString(Bill.BILL_TITLE));
				b.setAka(rs.getString(Bill.BILL_AKA));
				b.setDescription(rs.getString(Bill.BILL_DESCRIPTION));
				b.setDate(rs.getDate(Bill.BILL_DATE));
				b.setUrl(rs.getString(Bill.BILL_URL));

				bills.add(b);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return bills;
	}

	public static void updateBill(Bill b) {
		String sql = "UPDATE " + Bill.BILL_TABLE_NAME + " SET " + Bill.BILL_CANDIDATE_ID + " = ?, " + Bill.BILL_TITLE
				+ " = ?, " + Bill.BILL_AKA + " = ?, " + Bill.BILL_DESCRIPTION + " = ?, " + Bill.BILL_DATE + " = ?, "
				+ Bill.BILL_URL + " = ? " + " WHERE " + AcademicAward.ACADEMICAWARD_ACADEMIC_AWARD_ID + " = ?;";

		Connection conn = DBPool.getInstance().getConnection();
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, b.getCandidate_id());
			pstmt.setString(2, b.getTitle());
			pstmt.setString(3, b.getAka());
			pstmt.setString(4, b.getDescription());
			pstmt.setDate(5, b.getDate());
			pstmt.setString(6, b.getUrl());
			pstmt.setInt(7, b.getBill_id());

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public static void deleteBill(int bill_id) {

		String sql = "DELETE FROM " + Bill.BILL_TABLE_NAME + " WHERE " + Bill.BILL_BILL_ID + " =?";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bill_id);

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public static ArrayList<Bill> getAllBillByCandidate(int candidate_id) {
		ArrayList<Bill> bills = new ArrayList<>();
		String sql = "Select * from " + Bill.BILL_TABLE_NAME + " where candidate_id  = ?;";

		Connection conn = DBPool.getInstance().getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, candidate_id);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				Bill b = new Bill();
				b.setBill_id(rs.getInt(Bill.BILL_BILL_ID));
				b.setCandidate_id(rs.getInt(Bill.BILL_CANDIDATE_ID));
				b.setTitle(rs.getString(Bill.BILL_TITLE));
				b.setAka(rs.getString(Bill.BILL_AKA));
				b.setDescription(rs.getString(Bill.BILL_DESCRIPTION));
				b.setDate(rs.getDate(Bill.BILL_DATE));
				b.setUrl(rs.getString(Bill.BILL_URL));

				bills.add(b);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return bills;
	}
}
