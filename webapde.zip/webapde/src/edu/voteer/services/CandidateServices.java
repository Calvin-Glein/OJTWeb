package edu.voteer.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import edu.voteer.beans.Candidate;
import edu.voteer.db.DBPool;

public class CandidateServices {
	public static void addCandidate(Candidate c) {
		String sql = "INSERT INTO " + Candidate.CANDIDATE_TABLE_NAME + " (" + Candidate.CANDIDATE_FIRSTNAME + ", "
				+ Candidate.CANDIDATE_NICKNAME + ", " + Candidate.CANDIDATE_MIDDLENAME + ", "
				+ Candidate.CANDIDATE_LASTNAME + ", " + Candidate.CANDIDATE_BIRTHDATE + ", "
				+ Candidate.CANDIDATE_FATHER + ", " + Candidate.CANDIDATE_MOTHER + ", " + Candidate.CANDIDATE_RELIGION
				+ ", " + Candidate.CANDIDATE_PICTURE + ", " + Candidate.CANDIDATE_POSITION + ", "
				+ Candidate.CANDIDATE_DESCRIPTION + ") VALUES (?, ?, ?, ?, ?,?, ?, ?, ?, ?,?)";

		Connection conn = DBPool.getInstance().getConnection();

		// use preparedstatement to prevent sql injection

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, c.getFirstname());
			pstmt.setString(2, c.getNickname());
			pstmt.setString(3, c.getMiddlename());
			pstmt.setString(4, c.getLastname());
			pstmt.setDate(5, c.getBirthdate());
			pstmt.setString(6, c.getFather());
			pstmt.setString(7, c.getMother());
			pstmt.setString(8, c.getReligion());
			pstmt.setString(9, c.getPicture());
			pstmt.setString(10, c.getPosition());
			pstmt.setString(11, c.getDescription());

			pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public static ArrayList<Candidate> getAllCandidate() {
		ArrayList<Candidate> candidates = new ArrayList<>();

		String sql = "Select * from " + Candidate.CANDIDATE_TABLE_NAME + ";";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				Candidate c = new Candidate();
				c.setCandidate_id(rs.getInt(Candidate.CANDIDATE_CANDIDATE_ID));
				c.setFirstname(rs.getString(Candidate.CANDIDATE_FIRSTNAME));
				c.setNickname(rs.getString(Candidate.CANDIDATE_NICKNAME));
				c.setMiddlename(rs.getString(Candidate.CANDIDATE_MIDDLENAME));
				c.setLastname(rs.getString(Candidate.CANDIDATE_LASTNAME));
				c.setBirthdate(rs.getDate(Candidate.CANDIDATE_BIRTHDATE));
				c.setFather(rs.getString(Candidate.CANDIDATE_FATHER));
				c.setMother(rs.getString(Candidate.CANDIDATE_MOTHER));
				c.setReligion(rs.getString(Candidate.CANDIDATE_RELIGION));
				c.setPicture(rs.getString(Candidate.CANDIDATE_PICTURE));
				c.setPosition(rs.getString(Candidate.CANDIDATE_POSITION));
				c.setDescription(rs.getString(Candidate.CANDIDATE_DESCRIPTION));

				candidates.add(c);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return candidates;
	}

	public static void updateCandidate(Candidate c) {
		String sql = "UPDATE " + Candidate.CANDIDATE_TABLE_NAME + " SET " + Candidate.CANDIDATE_FIRSTNAME + " = ?, "
				+ Candidate.CANDIDATE_NICKNAME + " = ?,  " + Candidate.CANDIDATE_MIDDLENAME + " = ?, "
				+ Candidate.CANDIDATE_LASTNAME + " = ?, " + Candidate.CANDIDATE_BIRTHDATE + " = ?, "
				+ Candidate.CANDIDATE_FATHER + " = ?, " + Candidate.CANDIDATE_MOTHER + " = ?, "
				+ Candidate.CANDIDATE_RELIGION + " = ?, " + Candidate.CANDIDATE_PICTURE + " = ?, "
				+ Candidate.CANDIDATE_POSITION + " = ?, " + Candidate.CANDIDATE_DESCRIPTION + " = ? " + " WHERE "
				+ Candidate.CANDIDATE_CANDIDATE_ID + " = ?;";

		Connection conn = DBPool.getInstance().getConnection();
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, c.getFirstname());
			pstmt.setString(2, c.getNickname());
			pstmt.setString(3, c.getMiddlename());
			pstmt.setString(4, c.getLastname());
			pstmt.setDate(5, c.getBirthdate());
			pstmt.setString(6, c.getFather());
			pstmt.setString(7, c.getMother());
			pstmt.setString(8, c.getReligion());
			pstmt.setString(9, c.getPicture());
			pstmt.setString(10, c.getPosition());
			pstmt.setString(11, c.getDescription());
			pstmt.setInt(12, c.getCandidate_id());

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public static void deleteCandidate(int candidate_id) {

		String sql = "DELETE FROM " + Candidate.CANDIDATE_TABLE_NAME + " WHERE " + Candidate.CANDIDATE_CANDIDATE_ID
				+ " =?";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, candidate_id);

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public static Candidate getCandidate(int candidate_id) {
		String sql = "Select * from " + Candidate.CANDIDATE_TABLE_NAME + " where candidate_id = ?;";

		Connection conn = DBPool.getInstance().getConnection();

		Candidate c = new Candidate();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, candidate_id);

			rs = pstmt.executeQuery();

			while (rs.next()) {

				c.setCandidate_id(rs.getInt(Candidate.CANDIDATE_CANDIDATE_ID));
				c.setFirstname(rs.getString(Candidate.CANDIDATE_FIRSTNAME));
				c.setNickname(rs.getString(Candidate.CANDIDATE_NICKNAME));
				c.setMiddlename(rs.getString(Candidate.CANDIDATE_MIDDLENAME));
				c.setLastname(rs.getString(Candidate.CANDIDATE_LASTNAME));
				c.setBirthdate(rs.getDate(Candidate.CANDIDATE_BIRTHDATE));
				c.setFather(rs.getString(Candidate.CANDIDATE_FATHER));
				c.setMother(rs.getString(Candidate.CANDIDATE_MOTHER));
				c.setReligion(rs.getString(Candidate.CANDIDATE_RELIGION));
				c.setPicture(rs.getString(Candidate.CANDIDATE_PICTURE));
				c.setPosition(rs.getString(Candidate.CANDIDATE_POSITION));
				c.setDescription(rs.getString(Candidate.CANDIDATE_DESCRIPTION));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return c;
	}

}
