package edu.voteer.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import edu.voteer.beans.Video;
import edu.voteer.db.DBPool;

public class VideoServices {
	public static void addVideo(Video v) {
		String sql = "INSERT INTO " + Video.VIDEO_TABLE_NAME + " (" + Video.VIDEO_CANDIDATE_ID + ", "
				+ Video.VIDEO_TITLE + ", " + Video.VIDEO_DESCRIPTION + ", " + Video.VIDEO_URL + ") VALUES (?, ?, ?, ?)";

		Connection conn = DBPool.getInstance().getConnection();

		// use preparedstatement to prevent sql injection

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, v.getCandidate_id());

			pstmt.setString(2, v.getTitle());
			pstmt.setString(3, v.getDescription());
			pstmt.setString(4, v.getUrl());

			pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public static ArrayList<Video> getAllVideo() {
		ArrayList<Video> videos = new ArrayList<>();

		String sql = "Select * from " + Video.VIDEO_TABLE_NAME + ";";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				Video v = new Video();
				v.setVideo_id(rs.getInt(Video.VIDEO_VIDEO_ID));
				v.setCandidate_id(rs.getInt(Video.VIDEO_CANDIDATE_ID));
				v.setTitle(rs.getString(Video.VIDEO_TITLE));
				v.setDescription(rs.getString(Video.VIDEO_DESCRIPTION));
				v.setUrl(rs.getString(Video.VIDEO_URL));

				videos.add(v);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return videos;
	}

	public static void updateVideo(Video v) {
		String sql = "UPDATE " + Video.VIDEO_TABLE_NAME + " SET " + Video.VIDEO_CANDIDATE_ID + " = ?, "
				+ Video.VIDEO_TITLE + " = ?, " + Video.VIDEO_DESCRIPTION + " = ?, " + Video.VIDEO_URL + " = ? "
				+ " WHERE " + Video.VIDEO_VIDEO_ID + " = ?;";

		Connection conn = DBPool.getInstance().getConnection();
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, v.getCandidate_id());
			pstmt.setString(2, v.getTitle());
			pstmt.setString(3, v.getDescription());
			pstmt.setString(3, v.getUrl());
			pstmt.setInt(3, v.getVideo_id());

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public static void deleteVideo(int video_id) {

		String sql = "DELETE FROM " + Video.VIDEO_TABLE_NAME + " WHERE " + Video.VIDEO_VIDEO_ID + " =?";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, video_id);

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public static ArrayList<Video> getAllVideoByCandidate( int candidate_id) {
		ArrayList<Video> videos = new ArrayList<>();

		String sql = "Select * from " + Video.VIDEO_TABLE_NAME + " where candidate_id = ?;";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, candidate_id);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				Video v = new Video();
//				v.setVideo_id(rs.getInt(Video.VIDEO_VIDEO_ID));
				v.setCandidate_id(rs.getInt(Video.VIDEO_CANDIDATE_ID));
				v.setTitle(rs.getString(Video.VIDEO_TITLE));
				v.setDescription(rs.getString(Video.VIDEO_DESCRIPTION));
				v.setUrl(rs.getString(Video.VIDEO_URL));

				videos.add(v);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return videos;
	}
}
