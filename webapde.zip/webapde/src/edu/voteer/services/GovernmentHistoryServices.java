package edu.voteer.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import edu.voteer.beans.GovernmentHistory;
import edu.voteer.beans.GovernmentHistoryAchievement;
import edu.voteer.beans.GovernmentHistoryComposite;
import edu.voteer.db.DBPool;

public class GovernmentHistoryServices {
	public static void addGovernmentHistory(GovernmentHistory g) {
		String sql = "INSERT INTO " + GovernmentHistory.GOVERNMENTHISTORY_TABLE_NAME + " ("
				+ GovernmentHistory.GOVERNMENTHISTORY_CANDIDATE_ID + ", "
				+ GovernmentHistory.GOVERNMENTHISTORY_INSTITUTION + ") VALUES (?, ?)";

		Connection conn = DBPool.getInstance().getConnection();

		// use preparedstatement to prevent sql injection

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, g.getCandidate_id());
			pstmt.setString(2, g.getInstitution());

			pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public static ArrayList<GovernmentHistory> getAllGovernmentHistory() {
		ArrayList<GovernmentHistory> governmentHistories = new ArrayList<>();

		String sql = "Select * from " + GovernmentHistory.GOVERNMENTHISTORY_TABLE_NAME + ";";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				GovernmentHistory g = new GovernmentHistory();
				g.setGovernment_history_id(rs.getInt(GovernmentHistory.GOVERNMENTHISTORY_GOVERNMENT_HISTORY_ID));
				g.setCandidate_id(rs.getInt(GovernmentHistory.GOVERNMENTHISTORY_CANDIDATE_ID));
				g.setInstitution(rs.getString(GovernmentHistory.GOVERNMENTHISTORY_INSTITUTION));

				governmentHistories.add(g);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return governmentHistories;
	}

	public static void updateGovernmentHistory(GovernmentHistory g) {
		String sql = "UPDATE " + GovernmentHistory.GOVERNMENTHISTORY_TABLE_NAME + " SET "
				+ GovernmentHistory.GOVERNMENTHISTORY_CANDIDATE_ID + " = ?, "
				+ GovernmentHistory.GOVERNMENTHISTORY_INSTITUTION + " = ? " + " WHERE "
				+ GovernmentHistory.GOVERNMENTHISTORY_GOVERNMENT_HISTORY_ID + " = ?;";

		Connection conn = DBPool.getInstance().getConnection();
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, g.getCandidate_id());

			pstmt.setString(2, g.getInstitution());
			pstmt.setInt(3, g.getGovernment_history_id());

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public static void deleteGovernmentHistory(int government_history_id) {

		String sql = "DELETE FROM " + GovernmentHistory.GOVERNMENTHISTORY_TABLE_NAME + " WHERE "
				+ GovernmentHistory.GOVERNMENTHISTORY_GOVERNMENT_HISTORY_ID + " =?";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, government_history_id);

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public static ArrayList<GovernmentHistoryComposite> getAllGovernmentHistoryComposite(int candidate_id) {
		ArrayList<GovernmentHistoryComposite> governmentHistoriesComposite = new ArrayList<>();

		String sql = "SELECT * from " + GovernmentHistory.GOVERNMENTHISTORY_TABLE_NAME + ", "
				+ GovernmentHistoryAchievement.GOVERNMENTHISTORYACHIEVEMENT_TABLE_NAME
				+ " where government_history.government_history_id = government_history_achievements.government_history_id and government_history.candidate_id = ?;";

		Connection conn = DBPool.getInstance().getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, candidate_id);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				GovernmentHistoryComposite g = new GovernmentHistoryComposite();
				g.setGovernment_history_id(rs.getInt(GovernmentHistory.GOVERNMENTHISTORY_GOVERNMENT_HISTORY_ID));
				g.setCandidate_id(rs.getInt(GovernmentHistory.GOVERNMENTHISTORY_CANDIDATE_ID));
				g.setInstitution(rs.getString(GovernmentHistory.GOVERNMENTHISTORY_INSTITUTION));
				g.setPosition(rs.getString(GovernmentHistoryAchievement.GOVERNMENTHISTORYACHIEVEMENT_POSITION));
				
	
				governmentHistoriesComposite.add(g);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return governmentHistoriesComposite;
	}
}
