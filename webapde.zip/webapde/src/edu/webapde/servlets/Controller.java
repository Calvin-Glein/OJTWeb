package edu.webapde.servlets;

import java.io.IOException;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.voteer.beans.Academic;
import edu.voteer.beans.AcademicComposite;
import edu.voteer.beans.Bill;
import edu.voteer.beans.Candidate;
import edu.voteer.beans.GovernmentHistory;
import edu.voteer.beans.GovernmentProject;
import edu.voteer.beans.Law;
import edu.voteer.beans.NonPublicServantJobHistory;
import edu.voteer.beans.User;
import edu.voteer.beans.Video;
import edu.voteer.services.AcademicServices;
import edu.voteer.services.BillServices;
import edu.voteer.services.CandidateServices;
import edu.voteer.services.GovernmentHistoryServices;
import edu.voteer.services.GovernmentProjectServices;
import edu.voteer.services.LawServices;
import edu.voteer.services.NonPublicServantJobHistoryServices;
import edu.voteer.services.UserServices;
import edu.voteer.services.VideoServices;

/**
 * Servlet implementation class Controller
 */
@WebServlet(urlPatterns = { "/Controller", "/Login", "/AddAcademic", "/OpenAddAcademic", "/OpenAddAcademicAchievement",
		"/OpenAddLaw", "/AddLaw", "/OpenAddBill", "/AddBill", "/OpenAddVideo", "/AddVideo",
		"/OpenAddNonPublicServantHistory", "/AddNonPublicServantHistory", "/AddGovernmentHistory",
		"/OpenAddGovernmentHistory", "/AddGovernmentProject", "/OpenAddGovernmentProject", "/OpenPresidentiables",
		"/OpenPresidentiableProfile" })
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Controller() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		process(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		process(request, response);
	}

	protected void process(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String servletPath = request.getServletPath();
		int candidate_id;

		switch (servletPath) {
		case "/Login":
			String username = request.getParameter(User.USER_USERNAME);
			String password = request.getParameter(User.USER_PASSWORD);

			User u = UserServices.getUserAccount(username, password);
			System.out.println("1234: " + u.getUser_id());
			if (u.getUser_id() != -1) {
				request.setAttribute("candidates", getAllCandidates());
				request.getRequestDispatcher("/AdminView/AddAcademic.jsp").forward(request, response);
			}
			break;
		case "/AddAcademic":
			String institution = request.getParameter(Academic.ACADEMIC_INSTITUTION);
			String degree = request.getParameter(Academic.ACADEMIC_DEGREE);
			candidate_id = Integer.parseInt(request.getParameter("candidate_dropdown"));

			Academic a = new Academic(candidate_id, degree, institution);

			AcademicServices.addAcademic(a);
			request.setAttribute("candidates", getAllCandidates());
			request.getRequestDispatcher("/AdminView/AddAcademic.jsp").forward(request, response);

			break;

		case "/OpenAddAcademic":
			request.setAttribute("candidates", getAllCandidates());
			request.getRequestDispatcher("/AdminView/AddAcademic.jsp").forward(request, response);
			break;

		/*
		 * case "/OpenAddAcademicAchievement":
		 * request.setAttribute("candidates", getAllCandidates());
		 * request.setAttribute("academics", getAllAcademics());
		 * 
		 * request.getRequestDispatcher("/AdminView/AddAcademicAchievement.jsp")
		 * .forward(request, response); break; }
		 */
		case "/OpenAddLaw":
			request.setAttribute("candidates", getAllCandidates());
			request.getRequestDispatcher("/AdminView/AddLaw.jsp").forward(request, response);
			break;

		case "/AddLaw":
			String law_title = request.getParameter(Law.LAW_TITLE);
			String law_aka = request.getParameter(Law.LAW_AKA);
			String law_description = request.getParameter(Law.LAW_DESCRIPTION);
			String law_url = request.getParameter(Law.LAW_URL);
			String law_date = request.getParameter(Law.LAW_DATE);

			candidate_id = Integer.parseInt(request.getParameter("candidate_dropdown"));

			SimpleDateFormat sdfLaw = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date dateJavaLaw = null;
			try {
				dateJavaLaw = sdfLaw.parse(law_date);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			java.sql.Date sqlStartDateLaw = new Date(dateJavaLaw.getTime());

			Law l = new Law(candidate_id, law_title, law_aka, sqlStartDateLaw, law_description, law_url);

			LawServices.addLaw(l);
			/*
			 * request.setAttribute("candidates", getAllCandidates());
			 * request.getRequestDispatcher("/AdminView/AddAcademic.jsp").
			 * forward(request, response);
			 */
			break;

		case "/OpenAddBill":
			request.setAttribute("candidates", getAllCandidates());
			request.getRequestDispatcher("/AdminView/AddBill.jsp").forward(request, response);
			break;

		case "/AddBill":
			String bill_title = request.getParameter(Bill.BILL_TITLE);
			String bill_aka = request.getParameter(Bill.BILL_AKA);
			String bill_description = request.getParameter(Bill.BILL_DESCRIPTION);
			String bill_url = request.getParameter(Bill.BILL_URL);
			String bill_date = request.getParameter(Bill.BILL_DATE);

			candidate_id = Integer.parseInt(request.getParameter("candidate_dropdown"));

			SimpleDateFormat sdfBill = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date dateJavaBill = null;
			try {
				dateJavaBill = sdfBill.parse(bill_date);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			java.sql.Date sqlStartDateBill = new Date(dateJavaBill.getTime());

			Bill b = new Bill(candidate_id, bill_title, bill_aka, bill_description, sqlStartDateBill, bill_url);

			BillServices.addBill(b);
			/*
			 * request.setAttribute("candidates", getAllCandidates());
			 * request.getRequestDispatcher("/AdminView/AddAcademic.jsp").
			 * forward(request, response);
			 */
			break;

		case "/AddVideo":
			String title_video = request.getParameter(Video.VIDEO_TITLE);
			String description_video = request.getParameter(Video.VIDEO_DESCRIPTION);
			String url_video = request.getParameter(Video.VIDEO_URL);

			candidate_id = Integer.parseInt(request.getParameter("candidate_dropdown"));

			Video v = new Video(candidate_id, title_video, description_video, url_video);

			VideoServices.addVideo(v);
			request.setAttribute("candidates", getAllCandidates());
			request.getRequestDispatcher("/AdminView/AddVideo.jsp").forward(request, response);

			break;

		case "/OpenAddVideo":
			request.setAttribute("candidates", getAllCandidates());
			request.getRequestDispatcher("/AdminView/AddVideo.jsp").forward(request, response);
			break;

		case "/OpenAddNonPublicServantHistory":
			request.setAttribute("candidates", getAllCandidates());
			request.getRequestDispatcher("/AdminView/AddNonPublicServantHistory.jsp").forward(request, response);
			break;
		case "/AddNonPublicServantHistory":
			String position_nonPublicServantHistory = request
					.getParameter(NonPublicServantJobHistory.NONPUBLICSERVANTJOBHISTORY_POSITION);

			candidate_id = Integer.parseInt(request.getParameter("candidate_dropdown"));

			NonPublicServantJobHistory n = new NonPublicServantJobHistory(candidate_id,
					position_nonPublicServantHistory);

			NonPublicServantJobHistoryServices.addNonPublicServantJobHistory(n);
			request.setAttribute("candidates", getAllCandidates());
			request.getRequestDispatcher("/AdminView/AddNonPublicServantHistory.jsp").forward(request, response);

			break;
		case "/OpenAddGovernmentHistory":
			request.setAttribute("candidates", getAllCandidates());
			request.getRequestDispatcher("/AdminView/AddGovernmentHistory.jsp").forward(request, response);
			break;
		case "/AddGovernmentHistory":
			String institution_governmentHistory = request
					.getParameter(GovernmentHistory.GOVERNMENTHISTORY_INSTITUTION);

			candidate_id = Integer.parseInt(request.getParameter("candidate_dropdown"));

			GovernmentHistory g = new GovernmentHistory(candidate_id, institution_governmentHistory);

			GovernmentHistoryServices.addGovernmentHistory(g);
			request.setAttribute("candidates", getAllCandidates());
			request.getRequestDispatcher("/AdminView/AddGovernmentHistory.jsp").forward(request, response);

			break;

		case "/OpenAddGovernmentProject":
			request.setAttribute("candidates", getAllCandidates());
			request.getRequestDispatcher("/AdminView/AddGovernmentProject.jsp").forward(request, response);
			break;
		case "/AddGovernmentProject":
			String title_governmentProject = request.getParameter(GovernmentProject.GOVERNMENTPROJECT_TITLE);
			String description_governmentProject = request
					.getParameter(GovernmentProject.GOVERNMENTPROJECT_DESCRIPTION);

			candidate_id = Integer.parseInt(request.getParameter("candidate_dropdown"));

			GovernmentProject gP = new GovernmentProject(candidate_id, title_governmentProject,
					description_governmentProject);

			GovernmentProjectServices.addGovernmentProject(gP);
			request.setAttribute("candidates", getAllCandidates());
			request.getRequestDispatcher("/AdminView/AddGovernmentProject.jsp").forward(request, response);

			break;

		case "/OpenPresidentiables":
			request.setAttribute("candidates", getAllCandidates());
			request.getRequestDispatcher("presidentiables.jsp").forward(request, response);
			break;

		case "/OpenPresidentiableProfile":
			candidate_id = Integer.parseInt(request.getParameter(Candidate.CANDIDATE_CANDIDATE_ID));

			request.setAttribute("candidate", CandidateServices.getCandidate(candidate_id));

			request.setAttribute("laws", LawServices.getAllLawByCandidate(candidate_id));
			
			request.setAttribute("bills", BillServices.getAllBillByCandidate(candidate_id));

			request.setAttribute("governmentProjects",
					GovernmentProjectServices.getAllGovernmentProjectByCandidate(candidate_id));

			request.setAttribute("academicComposites", AcademicServices.getAllAcademicComposite(candidate_id));

			request.setAttribute("videos", VideoServices.getAllVideoByCandidate(candidate_id));

			request.setAttribute("nonPublicServantJobHistories",
					NonPublicServantJobHistoryServices.getAllNonPublicServantJobHistoryByCandidate(candidate_id));

			request.setAttribute("governmentHistoryComposite",
					GovernmentHistoryServices.getAllGovernmentHistoryComposite(candidate_id));

			request.getRequestDispatcher("presidentiable-profile.jsp").forward(request, response);
		}

	}

	private ArrayList<Academic> getAllAcademics() {
		ArrayList<Academic> academics = AcademicServices.getAllAcademic();
		return academics;
	}

	protected ArrayList<Candidate> getAllCandidates() {
		ArrayList<Candidate> candidates = CandidateServices.getAllCandidate();
		return candidates;
	}
}